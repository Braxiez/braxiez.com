import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

interface SocialCardProps {
  platform: string;
  username: string;
  url: string;
  icon: React.ReactNode;
  description: string;
}

export const SocialCard = ({ platform, username, url, icon, description }: SocialCardProps) => {
  return (
    <Card className="group relative overflow-hidden border-border/50 bg-gradient-card backdrop-blur-sm transition-all duration-300 hover:scale-105 hover:shadow-glow hover:border-brand-primary/50">
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-brand-primary/10 text-brand-primary group-hover:bg-brand-primary group-hover:text-primary-foreground transition-all duration-300">
              {icon}
            </div>
            <div>
              <h3 className="font-semibold text-lg">{platform}</h3>
              <p className="text-muted-foreground text-sm">{username}</p>
            </div>
          </div>
          <ExternalLink className="w-5 h-5 text-muted-foreground group-hover:text-brand-primary transition-colors duration-300" />
        </div>
        <p className="text-muted-foreground text-sm mb-4">{description}</p>
        <Button 
          variant="outline" 
          className="w-full group-hover:bg-brand-primary group-hover:text-primary-foreground group-hover:border-brand-primary transition-all duration-300"
          onClick={() => window.open(url, '_blank')}
        >
          Visit Profile
        </Button>
      </div>
      <div className="absolute inset-0 bg-gradient-primary opacity-0 group-hover:opacity-5 transition-opacity duration-300" />
    </Card>
  );
};