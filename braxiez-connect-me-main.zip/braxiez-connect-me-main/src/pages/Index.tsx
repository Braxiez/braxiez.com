import { HeroSection } from "@/components/HeroSection";
import { SocialCard } from "@/components/SocialCard";
import { 
  Instagram, 
  Youtube, 
  Linkedin, 
  Github, 
  Facebook, 
  MessageCircle,
  Music,
  Video,
  Users,
  Gamepad2
} from "lucide-react";

const Index = () => {
  const socialPlatforms = [
    {
      platform: "Instagram",
      username: "@braxiez.com",
      url: "https://instagram.com/braxiez.com",
      icon: <Instagram className="w-6 h-6" />,
      description: "Follow my daily updates and behind-the-scenes content"
    },
    {
      platform: "YouTube",
      username: "braxiez.com",
      url: "https://youtube.com/@braxiez.com",
      icon: <Youtube className="w-6 h-6" />,
      description: "Subscribe for tutorials, vlogs, and creative content"
    },
    {
      platform: "GitHub",
      username: "braxiez.com",
      url: "https://github.com/braxiez.com",
      icon: <Github className="w-6 h-6" />,
      description: "Check out my open source projects and contributions"
    },
    {
      platform: "Discord",
      username: "braxiez.com",
      url: "https://discord.gg/braxiez.com",
      icon: <MessageCircle className="w-6 h-6" />,
      description: "Join my Discord server for real-time chat and gaming"
    },
    {
      platform: "TikTok",
      username: "@braxiez.com",
      url: "https://tiktok.com/@braxiez.com",
      icon: <Video className="w-6 h-6" />,
      description: "Follow for short-form content and trending videos"
    },
    {
      platform: "Spotify",
      username: "braxiez.com",
      url: "https://open.spotify.com/user/braxiez.com",
      icon: <Music className="w-6 h-6" />,
      description: "Listen to my playlists and discover new music with me"
    },
    {
      platform: "Reddit",
      username: "u/braxiez.com",
      url: "https://reddit.com/u/braxiez.com",
      icon: <Users className="w-6 h-6" />,
      description: "Join discussions and see my posts across communities"
    },
    {
      platform: "Twitch",
      username: "braxiez.com",
      url: "https://twitch.tv/braxiez.com",
      icon: <Gamepad2 className="w-6 h-6" />,
      description: "Watch my live streams and gaming content"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <HeroSection />
      
      <section id="socials" className="py-20 px-6">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-primary bg-clip-text text-transparent">
              Find Me Everywhere
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Connect with me on your favorite platforms. Each one offers unique content and ways to interact.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {socialPlatforms.map((social, index) => (
              <SocialCard
                key={index}
                platform={social.platform}
                username={social.username}
                url={social.url}
                icon={social.icon}
                description={social.description}
              />
            ))}
          </div>
        </div>
      </section>
      
      <footer className="border-t border-border/50 py-8 px-6">
        <div className="container mx-auto text-center">
          <p className="text-muted-foreground">
            © 2024 Braxiez. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
